package com.example.englishbuddy;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private TextView status, timer;
    private Button mic;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false, sessionActive = false, listening = false;
    private long sessionStart = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private int turns = 0;
    private final Random random = new Random();

    private final String[] prompts = {
        "What do you usually do in the morning?",
        "Tell me about a food you enjoy.",
        "What would you like to do this weekend?",
        "Describe a place you would like to visit.",
        "What is something new you learned recently?",
        "Tell me about a person who inspires you.",
        "What do you usually do in your free time?",
        "If you could learn a new skill, what would it be?",
        "What kind of weather do you enjoy?",
        "Tell me about your favourite kind of music."
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("learning_memory", MODE_PRIVATE);
        buildScreen();
        tts = new TextToSpeech(this, this);
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 44);
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech recognition is not available on this phone.");
            mic.setEnabled(false);
        }
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 32, 28, 32);
        root.setBackgroundColor(Color.rgb(9, 18, 38));

        TextView title = new TextView(this);
        title.setText("ENGLISH BUDDY AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Your voice-only English practice partner");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = 12;
        root.addView(subtitle, sp);

        status = new TextView(this);
        status.setText("Press Start to begin speaking.");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, 0, 1);
        st.topMargin = 24;
        root.addView(status, st);

        timer = new TextView(this);
        timer.setText("00:00 / 30:00");
        timer.setTextColor(Color.rgb(130, 190, 255));
        timer.setTextSize(17);
        timer.setGravity(Gravity.CENTER);
        root.addView(timer, new LinearLayout.LayoutParams(-1, -2));

        mic = new Button(this);
        mic.setText("START SPEAKING");
        mic.setTextSize(17);
        mic.setAllCaps(false);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 76);
        bp.topMargin = 28;
        root.addView(mic, bp);
        mic.setOnClickListener(v -> {
            if (!sessionActive) startSession();
            else stopSession();
        });

        TextView note = new TextView(this);
        note.setText("Voice only • English only • Up to 30 minutes");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 22;
        root.addView(note, np);
        setContentView(root);
    }

    @Override public void onInit(int result) {
        if (result == TextToSpeech.SUCCESS) {
            int language = tts.setLanguage(Locale.US);
            ttsReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED;
            tts.setSpeechRate(0.88f);
        }
    }

    private void startSession() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 44);
            status.setText("Please allow microphone access, then press Start again.");
            return;
        }
        sessionActive = true;
        turns = 0;
        sessionStart = System.currentTimeMillis();
        mic.setText("END SESSION");
        status.setText("Hello! I am your English practice partner. How are you today?");
        speak("Hello! I am your English practice partner. How are you today?");
        updateTimer();
    }

    private void stopSession() {
        sessionActive = false;
        listening = false;
        if (recognizer != null) recognizer.cancel();
        mic.setText("START SPEAKING");
        status.setText("Great practice today. Press Start whenever you are ready again.");
        if (ttsReady) tts.speak("Great practice today. See you next time!", TextToSpeech.QUEUE_FLUSH, null, "bye");
        prefs.edit().putInt("total_turns", prefs.getInt("total_turns", 0) + turns)
            .putLong("last_session", System.currentTimeMillis()).apply();
    }

    private void updateTimer() {
        if (!sessionActive) return;
        long elapsed = System.currentTimeMillis() - sessionStart;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(elapsed);
        timer.setText(String.format(Locale.US, "%02d:%02d / 30:00", seconds / 60, seconds % 60));
        if (seconds >= 1800) {
            status.setText("Your 30-minute practice session is complete.");
            stopSession();
            return;
        }
        handler.postDelayed(this::updateTimer, 1000);
    }

    private void speak(String text) {
        if (ttsReady) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "english_buddy");
            handler.postDelayed(this::listen, Math.max(1200, text.length() * 55L));
        } else {
            status.setText("Install an English (US) voice in Android Text-to-Speech settings.");
        }
    }

    private void listen() {
        if (!sessionActive || listening) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("Speech recognition is unavailable. Check your phone's speech service.");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle p) { listening = true; status.setText("Listening... Speak in English."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rms) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() { listening = false; status.setText("Thinking..."); }
            @Override public void onError(int error) {
                listening = false;
                if (sessionActive) {
                    status.setText("I didn't catch that. Please try again.");
                    handler.postDelayed(MainActivity.this::listen, 900);
                }
            }
            @Override public void onResults(Bundle results) {
                listening = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String heard = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                handleAnswer(heard);
            }
            @Override public void onPartialResults(Bundle p) {}
            @Override public void onEvent(int event, Bundle p) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try { recognizer.startListening(intent); }
        catch (Exception e) { listening = false; status.setText("Could not start listening. Try again."); }
    }

    private void handleAnswer(String answer) {
        if (!sessionActive) return;
        turns++;
        String response = localTeacherReply(answer);
        status.setText(response);
        speak(response);
    }

    // A lightweight offline practice coach. This is not a full generative AI model.
    private String localTeacherReply(String input) {
        String s = input == null ? "" : input.trim().toLowerCase(Locale.US);
        if (s.isEmpty()) return "I did not hear an answer. Please try again.";
        String correction = null;

        if (s.matches(".*\\bi go\\b.*yesterday.*") || s.matches(".*\\bi eat\\b.*yesterday.*")) {
            correction = "Good try. For yesterday, use the past tense. Say: I went yesterday, or I ate yesterday. Please try again.";
        } else if (s.matches(".*\\bi am agree\\b.*")) {
            correction = "Good try. Say: I agree. We do not say I am agree. Can you repeat that?";
        } else if (s.matches(".*\\bhe go\\b.*") || s.matches(".*\\bshe go\\b.*")) {
            correction = "Small grammar tip. With he or she, say goes. For example: She goes to school. Please make a new sentence.";
        } else if (s.matches(".*\\bi has\\b.*")) {
            correction = "Small grammar tip. Say I have, not I has. Please repeat the correct form.";
        } else if (s.split("\\s+").length <= 2) {
            correction = "Nice start. Can you answer with a complete sentence and tell me a little more?";
        }

        if (correction != null) return correction;
        String[] praise = {"Good job! Your meaning is clear. ", "Thank you for your answer. ", "Nice speaking! ", "That is interesting. "};
        String follow = prompts[(turns + prefs.getInt("topic_offset", 0) + random.nextInt(prompts.length)) % prompts.length];
        return praise[random.nextInt(praise.length)] + "Let's continue. " + follow;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == 44 && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            status.setText("Microphone permission granted. Press Start.");
        }
    }

    @Override protected void onDestroy() {
        sessionActive = false;
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
